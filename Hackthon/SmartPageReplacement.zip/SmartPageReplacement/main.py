
from flask import Flask, render_template, request

app = Flask(__name__)


def simulate(pages, capacity, algorithm):
    frames = []
    fifo_order = []
    frequency = {}
    last_used = {}

    faults = 0
    hits = 0
    history = []

    for time, page in enumerate(pages):
        victim = None

        # Check whether the page is already in memory
        if page in frames:
            hits += 1
            status = "HIT"
            reason = "Page already in memory"

            if algorithm == "SMART":
                frequency[page] += 1

            last_used[page] = time

        else:
            faults += 1
            status = "FAULT"

            # Use an empty frame if available
            if len(frames) < capacity:
                reason = "Empty frame available"

            else:
                # Choose the page to replace
                if algorithm == "FIFO":
                    victim = fifo_order.pop(0)
                    reason = "Page entered memory first"

                elif algorithm == "LRU":
                    victim = min(
                        frames,
                        key=lambda p: last_used[p]
                    )
                    reason = "Page used least recently"

                elif algorithm == "SMART":
                    victim = min(
                        frames,
                        key=lambda p: (
                            frequency[p],
                            last_used[p]
                        )
                    )
                    reason = "Lowest frequency; LRU breaks ties"

                # Remove the victim from memory and tracking
                frames.remove(victim)
                frequency.pop(victim, None)
                last_used.pop(victim, None)

            # Load the requested page
            frames.append(page)
            fifo_order.append(page)
            frequency[page] = 1
            last_used[page] = time

        # Safety check: memory must never exceed capacity
        assert len(frames) <= capacity

        history.append({
            "page": page,
            "frames": frames.copy(),
            "status": status,
            "victim": victim,
            "reason": reason
        })

    total = len(pages)

    return {
        "faults": faults,
        "hits": hits,
        "fault_rate": faults / total * 100,
        "hit_rate": hits / total * 100,
        "history": history
    }


@app.route("/", methods=["GET", "POST"])
def index():
    results = None
    error = None
    pages_text = ""
    capacity = ""
    best_names = []
    total_pages = 0

    if request.method == "POST":
        pages_text = request.form.get("pages", "").strip()
        capacity_text = request.form.get("capacity", "").strip()

        try:
            if not pages_text:
                raise ValueError("Please enter a page sequence.")

            if not capacity_text:
                raise ValueError("Please enter the number of frames.")

            pages = list(map(int, pages_text.split()))
            capacity = int(capacity_text)

            if any(page < 0 for page in pages):
                raise ValueError("Page numbers cannot be negative.")

            if not 1 <= capacity <= 20:
                raise ValueError("Frames must be between 1 and 20.")

            if len(pages) > 200:
                raise ValueError("Enter at most 200 page requests.")

            total_pages = len(pages)

            results = {
                name: simulate(pages, capacity, name)
                for name in ("FIFO", "LRU", "SMART")
            }

            minimum = min(
                result["faults"]
                for result in results.values()
            )

            best_names = [
                name
                for name, result in results.items()
                if result["faults"] == minimum
            ]

        except ValueError as exc:
            error = str(exc) or "Please enter valid integer inputs."
            results = None

    return render_template(
        "index.html",
        results=results,
        error=error,
        pages_text=pages_text,
        capacity=capacity,
        total_pages=total_pages,
        best_names=best_names
    )


if __name__ == "__main__":
    app.run(debug=True)
